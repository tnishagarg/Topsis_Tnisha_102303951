# TOPSIS Python Package

This package implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.

## Installation
```bash
pip install Topsis-Tnisha-102303951
